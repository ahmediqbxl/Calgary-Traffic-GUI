import tkinter as tk
from tkinter import ttk
from pandastable import *
import matplotlib.pyplot as plt
import folium
from pandas import DataFrame
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

class GUI:
    # databases for this project - I could read using csv reader everytime but it takes too long

    A2016 = pd.DataFrame(pd.read_csv("Traffic_Incidents_Archive_2016.csv"))
    A2017 = pd.DataFrame(pd.read_csv("Traffic_Incidents_Archive_2017.csv"))
    A2018 = pd.DataFrame(pd.read_csv("Traffic_Incidents_Archive_2018.csv"))

    for i in range(A2016, A2017, A2018):
        i['frequency'] = i['Longitude'].map(i['Longitude'].value_counts())
        col = i.pop('frequency')
        i.insert(0, col.name, col)




    A2016 = pd.DataFrame(pd.read_csv("Traffic_Incidents_Archive_2016.csv"))
    A2016['frequency'] = A2016['Longitude'].map(A2016['Longitude'].value_counts())
    col = A2016.pop('frequency')
    A2016.insert(0, col.name, col)

    A2017 = pd.DataFrame(pd.read_csv("Traffic_Incidents_Archive_2017.csv"))
    A2017['frequency'] = A2017['Longitude'].map(A2017['Longitude'].value_counts())
    col = A2017.pop('frequency')
    A2017.insert(0, col.name, col)

    A2018 = pd.DataFrame(pd.read_csv("Traffic_Incidents_Archive_2018.csv"))
    A2018['frequency'] = A2018['Longitude'].map(A2018['Longitude'].value_counts())
    col = A2018.pop('frequency')
    A2018.insert(0, col.name, col)

    V2016 = pd.DataFrame(pd.read_csv("TrafficFlow2016_OpenData.csv"))
    temp2016 = V2016["the_geom"].str.split('[A-Za-z]+', expand=True)
    temp2016 = temp2016[1].str.split('\(', expand=True)
    temp2016 = temp2016[2].str.split(',', expand=True)
    temp2016 = temp2016[0].str.split(' ', expand=True)
    V2016[['Longitude', 'Latitude']] = temp2016[[0, 1]]

    V2017 = pd.DataFrame(pd.read_csv("2017_Traffic_Volume_Flow.csv"))
    temp2017 = V2017["the_geom"].str.split('[A-Za-z]+', expand=True)
    temp2017 = temp2017[1].str.split('\(', expand=True)
    temp2017 = temp2017[2].str.split(',', expand=True)
    temp2017 = temp2017[0].str.split(' ', expand=True)
    V2017[['Longitude', 'Latitude']] = temp2017[[0, 1]]

    V2018 = pd.DataFrame(pd.read_csv("Traffic_Volumes_for_2018.csv"))
    temp2018 = V2018["the_geom"].str.split('[A-Za-z]+', expand=True)
    temp2018 = temp2018[1].str.split('\(', expand=True)
    temp2018 = temp2018[2].str.split(',', expand=True)
    temp2018 = temp2018[0].str.split(' ', expand=True)
    V2018[['Longitude', 'Latitude']] = temp2018[[0, 1]]

    def clearFrame(self):  # clear button for Frame1
        for widget in frame1.winfo_children():
            widget.destroy()

    def read_input(self):
        if cb1.get() == 'Accident':  # need to sum up all the accidents
            if cb2.get() == '2016':
                A2016 = pd.DataFrame(pd.read_csv("Traffic_Incidents_Archive_2016.csv"))
                return A2016
            if cb2.get() == '2017':
                A2017 = pd.DataFrame(pd.read_csv("Traffic_Incidents_Archive_2017.csv"))
                return A2017
            if cb2.get() == '2018':
                A2018 = pd.DataFrame(pd.read_csv("Traffic_Incidents_Archive_2018.csv"))
                return A2018

        elif cb1.get() == 'Traffic Volume':  # need to sum up all the volume for the graph
            if cb2.get() == '2016':
                return V2016
            if cb2.get() == '2017':
                return V2017
            if cb2.get() == '2018':
                return V2018

    def reader(self):
        df = read_input()
        cols = list(df.columns)

        tree = Treeview(frame1)
        tree.pack()
        tree["columns"] = cols

        for i in cols:
            tree.column(i, anchor="w")
            tree.heading(i, text=i, anchor='w')

        for index, row in df.iterrows():
            tree.insert("", 0, text=index, values=list(row))

    def sort(self):
        if cb1.get() == 'Traffic Volume':  # need to sum up all the volume for the graph
            if cb2.get() == '2016':
                col = V2016.pop('volume')
                V2016.insert(0, col.name, col)
                result = V2016.sort_values(['volume'], ascending=True)
                return result
            if cb2.get() == '2017':
                col = V2017.pop('volume')
                V2017.insert(0, col.name, col)
                result = V2017.sort_values(['volume'], ascending=True)
                return result
            if cb2.get() == '2018':
                col = V2018.pop('volume')
                V2018.insert(0, col.name, col)
                result = V2018.sort_values(['volume'], ascending=True)
                return result

        elif cb1.get() == 'Accident':
            if cb2.get() == '2016':
                result = A2016.sort_values(['frequency'], ascending=True)
                return result
            if cb2.get() == '2017':
                result = A2017.sort_values(['frequency'], ascending=True)
                return result
            if cb2.get() == '2018':
                result = A2018.sort_values(['frequency'], ascending=True)
                return result

    def sorted_table(self):  # prints the sorted table, the command for sort
        df = sort()
        cols = list(df.columns)

        tree = Treeview(frame1)
        tree.pack()
        tree["columns"] = cols

        for i in cols:
            tree.column(i, anchor="w")
            tree.heading(i, text=i, anchor='w')

        for index, row in df.iterrows():
            tree.insert("", 0, text=index, values=list(row))

    def analysis(self):  # creates the graph of either max volume or number of accidents
        Volume = {'Year': [2016, 2017, 2018],
                  'Maximum Volume': [V2016['volume'].max(), V2017['volume'].max(), V2018['volume'].max()]}
        Vol = DataFrame(Volume, columns=['Year', 'Maximum Volume'])

        Accidents = {'Year': [2016, 2017, 2018],
                     'Maximum Accidents': [A2016['frequency'].max(), A2017['frequency'].max(),
                                           A2018['frequency'].max()]}
        Acc = DataFrame(Accidents, columns=['Year', 'Maximum Accidents'])

        if cb1.get() == 'Accident':
            figure = plt.Figure(figsize=(5, 4), dpi=100)
            ax = figure.add_subplot(111)
            line2 = FigureCanvasTkAgg(figure, frame1)
            line2.get_tk_widget().pack(side=tk.LEFT, fill=tk.BOTH)
            df = Acc[['Year', 'Maximum Accidents']].groupby('Year').sum()
            df.plot(kind='line', legend=True, ax=ax, color='b', marker='o', fontsize=10)
            ax.set_title('Highest Accident Frequency in Calgary per Year')

        if cb1.get() == 'Traffic Volume':
            figure = plt.Figure(figsize=(5, 4), dpi=100)
            ax = figure.add_subplot(111)
            line2 = FigureCanvasTkAgg(figure, frame1)
            line2.get_tk_widget().pack(side=tk.LEFT, fill=tk.BOTH)
            df = Vol[['Year', 'Maximum Volume']].groupby('Year').sum()
            df.plot(kind='line', legend=True, ax=ax, color='b', marker='o', fontsize=10)
            ax.set_title('Highest Traffic Volume in Calgary per Year')

    def map(self):  # writes and HTML file with the map of calgary and location with maximum accident or traffic
        map = folium.Map(location=[51.0447, -114.0719], zoom_start=12)
        temp = sort()
        folium.Marker(location=[temp['Latitude'].iloc[-1], temp['Longitude'].iloc[-1]]).add_to(map)
        map.save('map.html')
        map

    def __init__(self, master):
        root = Tk()
        #root.title("Ahmed's Project")
        root.geometry("1000x500")

        # frame for the buttons and combobox
        frame = Frame(root)
        frame.pack(side=tk.LEFT, expand=False, fill=BOTH)

        # frame1 for the results
        frame1 = Frame(root)
        frame1.pack(side=tk.RIGHT, expand=True, fill=BOTH)

        # Buttons
        n = tk.StringVar()
        cb1 = ttk.Combobox(frame, width=18, textvariable=n)
        cb1['values'] = ('Accident', 'Traffic Volume')
        cb1.grid(row=1, column=0, pady=10, padx=10)

        m = tk.IntVar()
        cb2 = ttk.Combobox(frame, width=18, textvariable=m)
        cb2['values'] = ('2016', '2017', '2018')
        cb2.grid(row=2, column=0, pady=10, padx=10)

        b2 = Button(frame, text="Read", command=reader, width=20)  # this needs to display the year in question
        b2.grid(row=4, column=0, pady=10)

        b3 = Button(frame, text="Sort", command=sorted_table, width=20)  # this needs to display the year in question
        b3.grid(row=5, column=0, pady=10)

        b4 = Button(frame, text="Analysis", command=analysis, width=20)  # this needs to display the year in question
        b4.grid(row=6, column=0, pady=10)

        b5 = Button(frame, text="Map", command=map, width=20)  # this needs to display the year in question
        b5.grid(row=7, column=0, pady=10)

        b5 = Button(frame, text="Clear Window", command=clearFrame,
                    width=20)  # this needs to display the year in question
        b5.grid(row=8, column=0, pady=10)

        # status message
        status = Label(frame, text="Status")  # every function need to return its own message, so will need
        # to update
        status.grid(row=9, column=0, pady=10)

if __name__ == "__main__":
    root = Tk()
    GUI = GUI(root)
    GUI.pack()
    GUI.mainloop