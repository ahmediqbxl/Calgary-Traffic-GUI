# Ahmed Iqbal ENSF 592 Project Phase 1 - July 23, 2020

import tkinter as tk  # tkinter for the gui
from tkinter import ttk
#from pandastable import * # for the table
from tkinter.ttk import Treeview

import pandas as pd
import matplotlib.pyplot as plt  # for the plot
import folium  # for the mapping
from pandas import DataFrame  # for the database and csv_reader
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg  # for the plot


class GUI:
    # incident databases
    A2016 = pd.DataFrame(pd.read_csv("Traffic_Incidents_Archive_2016.csv"))
    A2017 = pd.DataFrame(pd.read_csv("Traffic_Incidents_Archive_2017.csv"))
    A2018 = pd.DataFrame(pd.read_csv("Traffic_Incidents_Archive_2018.csv"))

    # volume databases
    V2016 = pd.DataFrame(pd.read_csv("TrafficFlow2016_OpenData.csv"))
    V2017 = pd.DataFrame(pd.read_csv("2017_Traffic_Volume_Flow.csv"))
    V2018 = pd.DataFrame(pd.read_csv("Traffic_Volumes_for_2018.csv"))

    acc = [A2016, A2017, A2018]
    vol = [V2016, V2017, V2018]

    # counting the frequency of incidents
    for i in range(len(acc)):
        acc[i]['frequency'] = acc[i]['Longitude'].map(
            acc[i]['Longitude'].value_counts())  # value_counts counts the occurrences in a list
        col = acc[i].pop('frequency')
        acc[i].insert(0, col.name, col)  # inserts frequency column at the beginning

    # split the MULTILINESTRING in "the_geom" column into longitude and latitude
    for i in range(len(vol)):
        temp = vol[i]["the_geom"].str.split('[A-Za-z]+', expand=True)
        temp = temp[1].str.split('\(', expand=True)
        temp = temp[2].str.split(',', expand=True)
        temp = temp[0].str.split(' ', expand=True)
        vol[i][['Longitude', 'Latitude']] = temp[[0, 1]]  # creates a longitude and lattitude column

    def __init__(self):
        pass

    def read_input(self):  # returns the correct database from what was inputted in the combobox
        if self.n.get() == 'Accident':  # n is for combobox 1, m is for combobox 2
            if self.m.get() == 2016:
                return self.A2016
            if self.m.get() == 2017:
                return self.A2017
            if self.m.get() == 2018:
                return self.A2018

        elif self.n.get() == 'Traffic Volume':
            if self.m.get() == 2016:
                return self.V2016
            if self.m.get() == 2017:
                return self.V2017
            if self.m.get() == 2018:
                return self.V2018

    def table(self, df):  # creates the table
        cols = list(df.columns)  # gives us a list of the column names

        tree = Treeview(self.frame1)  # Treeview is a widget used to display items
        tree.pack()
        tree["columns"] = cols  # columns for the tree

        for i in cols:  # for printing the columns and headings
            tree.column(i, anchor="w")
            tree.heading(i, text=i, anchor='w')

        for index, row in df.iterrows():  # inserts the values from df, which is the sorted table. iterrows iterates
            # over DataFrame rows as (index, Series) pairs.
            tree.insert("", 0, text=index, values=list(row))

    def reader(self):  # prints the table
        df = self.read_input()  # gets the correct database
        self.table(df)

    def sort(self):  # sorts the database accordingly
        if self.n.get() == 'Traffic Volume':
            data = self.read_input()
            result = data.sort_values(['volume'], ascending=True)  # sort the volume column ascending
            return result

        elif self.n.get() == 'Accident':
            data = self.read_input()
            result = data.sort_values(['frequency'], ascending=True)  # sort the frequency column ascending
            # note how we counted the frequency in line 22
            return result

    def sorted_table(self):  # prints the sorted table from the sort(self) function
        df = self.sort()  # get the sorted database
        self.table(df)

    def analysis(self):  # creates the graph of either max volume or number of accidents
        Volume = {'Year': ['2016', '2017', '2018'],
                  'Maximum Volume': [self.V2016['volume'].max(), self.V2017['volume'].max(),
                                     self.V2018['volume'].max()]}  # dictionary to input into the dataframe
        Vol = DataFrame(Volume, columns=['Year', 'Maximum Volume'])  # using this dataframe for plotting volume

        Accidents = {'Year': ['2016', '2017', '2018'],
                     'Maximum Accidents': [self.A2016['frequency'].max(), self.A2017['frequency'].max(),
                                           self.A2018['frequency'].max()]}
        Acc = DataFrame(Accidents, columns=['Year', 'Maximum Accidents'])

        if self.n.get() == 'Accident':
            figure = plt.Figure(figsize=(5, 4), dpi=100)
            ax = figure.add_subplot(111)  # axis
            line2 = FigureCanvasTkAgg(figure, self.frame1)  # adds the plot to the GUI
            line2.get_tk_widget().pack(side=tk.LEFT, fill=tk.BOTH)
            df = Acc[['Year', 'Maximum Accidents']].groupby('Year').sum()
            df.plot(kind='line', legend=True, ax=ax, color='b', marker='o', fontsize=10)  # plots the data
            ax.set_title('Highest Accident Frequency in Calgary per Year')

        if self.n.get() == 'Traffic Volume':
            figure = plt.Figure(figsize=(5, 4), dpi=100)
            ax = figure.add_subplot(111)
            line2 = FigureCanvasTkAgg(figure, self.frame1)
            line2.get_tk_widget().pack(side=tk.LEFT, fill=tk.BOTH)
            df = Vol[['Year', 'Maximum Volume']].groupby('Year').sum()
            df.plot(kind='line', legend=True, ax=ax, color='b', marker='o', fontsize=10)
            ax.set_title('Highest Traffic Volume in Calgary per Year')

    def map(self):  # writes and HTML file with the map of calgary and location with maximum accident or traffic
        map = folium.Map(location=[51.0447, -114.0719], zoom_start=12)
        temp = self.sort()  # need the sorted table to get the maximum value as the first value
        folium.Marker(location=[temp['Latitude'].iloc[-1], temp['Longitude'].iloc[-1]]).add_to(map)  # adds markers
        map.save('map.html')
        map

    def clearFrame(self):  # clear Frame1
        for widget in self.frame1.winfo_children():
            widget.destroy()

    def add(self):  # for the status button
        status = tk.Label(self.frame, text="Status: Successful")
        status.config(background='green')
        status.grid(row=9, column=0, pady=10)

    def gui_layout(self):  # creates the GUI layout
        root = tk.Tk()  # creates the window
        root.title("Ahmed's Project")
        root.geometry("1000x500")

        # frame for the buttons and combobox
        self.frame = tk.Frame(root)
        self.frame.pack(side=tk.LEFT, expand=False, fill=tk.BOTH)

        # frame1 for the results
        self.frame1 = tk.Frame(root)
        self.frame1.pack(side=tk.RIGHT, expand=True, fill=tk.BOTH)

        # comboboxes
        self.n = tk.StringVar()
        cb1 = ttk.Combobox(self.frame, width=18, textvariable=self.n, values=('Accident', 'Traffic Volume'))
        cb1.grid(row=1, column=0, pady=10, padx=10)

        self.m = tk.IntVar()
        cb2 = ttk.Combobox(self.frame, width=18, textvariable=self.m, values=(2016, 2017, 2018))
        cb2.grid(row=2, column=0, pady=10, padx=10)

        # Buttons
        b2 = tk.Button(self.frame, text="Read", command=lambda: [self.reader(), self.add()],
                       width=20)  # this needs to display the year in question
        b2.grid(row=4, column=0, pady=10)

        b3 = tk.Button(self.frame, text="Sort", command=lambda: [self.sorted_table(), self.add()],
                       width=20)  # this needs to display the year in question
        b3.grid(row=5, column=0, pady=10)

        b4 = tk.Button(self.frame, text="Analysis", command=lambda: [self.analysis(), self.add()],
                       width=20)  # this needs to display the year in question
        b4.grid(row=6, column=0, pady=10)

        b5 = tk.Button(self.frame, text="Map", command=lambda: [self.map(), self.add()], width=20)
        b5.grid(row=7, column=0, pady=10)

        b5 = tk.Button(self.frame, text="Clear Window", command=self.clearFrame,
                       width=20)  # this needs to display the year in question
        b5.grid(row=8, column=0, pady=10)


class Interface:  # creates the GUI, called in main
    def __init__(self):
        gui = GUI()
        gui.gui_layout()


if __name__ == "__main__":
    Interface()
    tk.mainloop()
