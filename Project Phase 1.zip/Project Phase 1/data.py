import tkinter as tk
from tkinter import ttk
from pandastable import *
import matplotlib.pyplot as plt
import folium
from pandas import DataFrame
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# databases for this project
A2016 = pd.DataFrame(pd.read_csv("Traffic_Incidents_Archive_2016.csv"))
A2017 = pd.DataFrame(pd.read_csv("Traffic_Incidents_Archive_2017.csv"))
A2018 = pd.DataFrame(pd.read_csv("Traffic_Incidents_Archive_2018.csv"))

V2016 = pd.DataFrame(pd.read_csv("TrafficFlow2016_OpenData.csv"))
V2017 = pd.DataFrame(pd.read_csv("2017_Traffic_Volume_Flow.csv"))
V2018 = pd.DataFrame(pd.read_csv("Traffic_Volumes_for_2018.csv"))

acc = [A2016, A2017, A2018]
vol = [V2016, V2017, V2018]

#adding a frequency column
for i in range(len(acc)):
    acc[i]['frequency'] = acc[i]['Longitude'].map(acc[i]['Longitude'].value_counts())
    col = acc[i].pop('frequency')
    acc[i].insert(0, col.name, col)

#splitting the multistring
for i in range(len(vol)):
    temp = vol[i]["the_geom"].str.split('[A-Za-z]+', expand=True)
    temp = temp[1].str.split('\(', expand=True)
    temp = temp[2].str.split(',', expand=True)
    temp = temp[0].str.split(' ', expand=True)
    vol[i][['Longitude', 'Latitude']] = temp[[0, 1]]

#clears the frame
def clearFrame():  # clear button for Frame1
    for widget in frame1.winfo_children():
        widget.destroy()


def read_input():
    if cb1.get() == 'Accident':  # need to sum up all the accidents
        if cb2.get() == '2016':
            return A2016
        if cb2.get() == '2017':
            return A2017
        if cb2.get() == '2018':
            return A2018

    elif cb1.get() == 'Traffic Volume':  # need to sum up all the volume for the graph
        if cb2.get() == '2016':
            return V2016
        if cb2.get() == '2017':
            return V2017
        if cb2.get() == '2018':
            return V2018


def reader():
    df = read_input()
    cols = list(df.columns)

    tree = Treeview(frame1)
    tree.pack()
    tree["columns"] = cols

    for i in cols:
        tree.column(i, anchor="w")
        tree.heading(i, text=i, anchor='w')

    for index, row in df.iterrows():
        tree.insert("", 0, text=index, values=list(row))


def sort():
    if cb1.get() == 'Traffic Volume':  # need to sum up all the volume for the graph
        data = read_input()
        col = data.pop('volume')
        data.insert(0, col.name, col)
        result = data.sort_values(['volume'], ascending=True)
        return result

    elif cb1.get() == 'Accident':
        data = read_input()
        result = data.sort_values(['frequency'], ascending=True)
        return result


def sorted_table():  # prints the sorted table, the command for sort
    df = sort()
    cols = list(df.columns)

    tree = Treeview(frame1)
    tree.pack()
    tree["columns"] = cols

    for i in cols:
        tree.column(i, anchor="w")
        tree.heading(i, text=i, anchor='w')

    for index, row in df.iterrows():
        tree.insert("", 0, text=index, values=list(row))


def analysis():  # creates the graph of either max volume or number of accidents
    Volume = {'Year': [2016, 2017, 2018],
              'Maximum Volume': [V2016['volume'].max(), V2017['volume'].max(), V2018['volume'].max()]}
    Vol = DataFrame(Volume, columns=['Year', 'Maximum Volume'])

    Accidents = {'Year': [2016, 2017, 2018],
                 'Maximum Accidents': [A2016['frequency'].max(), A2017['frequency'].max(), A2018['frequency'].max()]}
    Acc = DataFrame(Accidents, columns=['Year', 'Maximum Accidents'])

    if cb1.get() == 'Accident':
        figure = plt.Figure(figsize=(5, 4), dpi=100)
        ax = figure.add_subplot(111)
        line2 = FigureCanvasTkAgg(figure, frame1)
        line2.get_tk_widget().pack(side=tk.LEFT, fill=tk.BOTH)
        df = Acc[['Year', 'Maximum Accidents']].groupby('Year').sum()
        df.plot(kind='line', legend=True, ax=ax, color='b', marker='o', fontsize=10)
        ax.set_title('Highest Accident Frequency in Calgary per Year')

    if cb1.get() == 'Traffic Volume':
        figure = plt.Figure(figsize=(5, 4), dpi=100)
        ax = figure.add_subplot(111)
        line2 = FigureCanvasTkAgg(figure, frame1)
        line2.get_tk_widget().pack(side=tk.LEFT, fill=tk.BOTH)
        df = Vol[['Year', 'Maximum Volume']].groupby('Year').sum()
        df.plot(kind='line', legend=True, ax=ax, color='b', marker='o', fontsize=10)
        ax.set_title('Highest Traffic Volume in Calgary per Year')


def map():  # writes and HTML file with the map of calgary and location with maximum accident or traffic
    map = folium.Map(location=[51.0447, -114.0719], zoom_start=12)
    temp = sort()
    folium.Marker(location=[temp['Latitude'].iloc[-1], temp['Longitude'].iloc[-1]]).add_to(map)
    map.save('map.html')


root = Tk()
root.title("Ahmed's Project")
root.geometry("1000x500")

# frame for the buttons and combobox
frame = Frame(root)
frame.pack(side=tk.LEFT, expand=False, fill=BOTH)

# frame1 for the results
frame1 = Frame(root)
frame1.pack(side=tk.RIGHT, expand=True, fill=BOTH)

# Buttons
n = tk.StringVar()
cb1 = ttk.Combobox(frame, width=18, textvariable=n)
cb1['values'] = ('Accident', 'Traffic Volume')
cb1.grid(row=1, column=0, pady=10, padx=10)

m = tk.IntVar()
cb2 = ttk.Combobox(frame, width=18, textvariable=m)
cb2['values'] = ('2016', '2017', '2018')
cb2.grid(row=2, column=0, pady=10, padx=10)

b2 = Button(frame, text="Read", command=reader, width=20)  # this needs to display the year in question
b2.grid(row=4, column=0, pady=10)

b3 = Button(frame, text="Sort", command=sorted_table, width=20)  # this needs to display the year in question
b3.grid(row=5, column=0, pady=10)

b4 = Button(frame, text="Analysis", command=analysis, width=20)  # this needs to display the year in question
b4.grid(row=6, column=0, pady=10)

b5 = Button(frame, text="Map", command=map, width=20)  # this needs to display the year in question
b5.grid(row=7, column=0, pady=10)

b5 = Button(frame, text="Clear Window", command=clearFrame, width=20)  # this needs to display the year in question
b5.grid(row=8, column=0, pady=10)

# status message
status = Label(frame, text="Status")  # every function need to return its own message, so will need
# to update
status.grid(row=9, column=0, pady=10)

root.mainloop()